# LagosJavaDevelopers
An Android app that retrieve the list of Java Developers in Lagos using the Github API.
