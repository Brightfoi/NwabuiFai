# CryptoCurrency_Converter
This is a cryptocurrency converter android app, that converts two popular cryptocurrencies (BTC and ETH) to 20 world popular currencies (NGN,USD,EUR,JPY,GBP,CHF,CAD,AUD,ZAR,CNY,INR,SGD,TWD,RUB,MXN,ILS,MYR,SEK,NOK,TRY)
